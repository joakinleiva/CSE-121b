const movieInfo = [
    {
        name: "The Dark Knight",
        year: 2008,
        rating: 9.0,
        image: "https://image.tmdb.org/t/p/w500/qJ2tW6WMUDux911r6m7haRef0WH.jpg",
    },
    {
        name: "Inception",
        year: 2010,
        rating: 8.8,
        image: "https://image.tmdb.org/t/p/w500/9gk7adHYeDvHkCSEqAvQNLV5Uge.jpg",
    },
    {
        name: "Interstellar",
        year: 2014,
        rating: 8.6,
        image: "https://image.tmdb.org/t/p/w500/gEU2QniE6E77NI6lCU6MxlNBvIx.jpg",
    },
];